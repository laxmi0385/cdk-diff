
import { Stage, StageProps } from "aws-cdk-lib"
import { Construct } from "constructs";
import { LambdaStack } from "./LambdaStack"
import { CodeBuildStep } from "aws-cdk-lib/pipelines";
export class ZAP extends Stage {
    constructor(scope: Construct, id: string, props: StageProps) {
        super(scope, id, props)
        
        new LambdaStack(this, 'LambdaStack', {
            stageName: props.stageName,
            commands: ["npm install -g zap-cli"]
        })
        // this.addZapTest();      //calling addSonarQubeScan method here
        
    }
    private addZapTest() {
        const zapTestCommand = "zap-cli quick-scan -r -s xss,sqli --htmlreport zap-report.html https://example.com";
    
        const zaptest = new CodeBuildStep("zaptest", {
          commands: [
            "npm install -g zap-cli", // Install OSWAP ZAP globally (if not installed)
            zapTestCommand,
          ],
          // ... (other CodeBuildStep options)
        });
    
        
    }
}