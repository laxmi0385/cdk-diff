import * as cdk from "aws-cdk-lib";
// import * as codecommit from "aws-cdk-lib/aws-codecommit";
import { Stack, StackProps, aws_codecommit } from "aws-cdk-lib";
import { Construct } from "constructs";
import {
  CodeBuildStep,
  CodePipeline,
  CodePipelineSource,
  ManualApprovalStep,
  ShellStep,
} from "aws-cdk-lib/pipelines";
import { PipelineStage } from "./SonarQube";
import { Production } from "./Production";
import { accounts, mainRegion } from "./constant/account";
import { ZAP } from "./ZAP";

export class NexaraCdkDeploymentStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
      super(scope, id, props);
  
      const repo = aws_codecommit.Repository.fromRepositoryArn(
        this,
        id,
        `arn:aws:codecommit:${Stack.of(this).region}:${Stack.of(this).account}:pocnexararepo`);

    const prebuild = new cdk.pipelines.ShellStep('Prebuild', {
    input: cdk.pipelines.CodePipelineSource.gitHub('myorg/repo1', 'main'),
    primaryOutputDirectory: './build',
    commands: ['./build.sh'],
  });
  
    const pipeline = new cdk.pipelines.CodePipeline(this, 'Pipeline', {
    synth: new cdk.pipelines.ShellStep('Synth', {
      input: cdk.pipelines.CodePipelineSource.gitHub('myorg/repo2', 'main'),
      additionalInputs: {
        'subdir': cdk.pipelines.CodePipelineSource.gitHub('myorg/repo3', 'main'),
        '../siblingdir': prebuild,
      },
  
      commands: ['./build.sh'],
    })
  });
}
}