import * as cdk from "aws-cdk-lib";
// import * as codecommit from "aws-cdk-lib/aws-codecommit";
import { Stack, StackProps, aws_codecommit } from "aws-cdk-lib";
import { Construct } from "constructs";
import {
  CodeBuildStep,
  CodePipeline,
  CodePipelineSource,
  ManualApprovalStep,
  ShellStep,
} from "aws-cdk-lib/pipelines";
import { PipelineStage } from "./SonarQube";
import { Production } from "./Production";
import { accounts, mainRegion } from "./constant/account";
import { ZAP } from "./ZAP";



export class NexaraCdkDeploymentStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const repo = aws_codecommit.Repository.fromRepositoryArn(
      this,
      id,
      `arn:aws:codecommit:${Stack.of(this).region}:${Stack.of(this).account}:pocnexararepo`);
     // const repo = codecommit.Repository.fromRepositoryName(
     //   this,
     //   "ExistingRepo",
     //   "pocnexararepo"
     // );

    const pipeline = new CodePipeline(this, "Pipeline", {
      pipelineName: "InfrastructurePipeline",
      selfMutation: true,
      crossAccountKeys: false,
      synth: new ShellStep("Synth", {
          input: CodePipelineSource.codeCommit(repo, "master"),
          commands: ['npm ci', 'npm i constructs', 'npm run build', 'npx cdk synth'
                    //  'npm install -g sonarqube-scanner', 'sonar-scanner -Dsonar.host.url=https://100.25.48.193:9000/ -Dsonar.login=nexara',
                    //  'npm install -g zap-cli', 'zap-cli quick-scan -r -s xss,sqli --htmlreport zap-report.html https://example.com'
        ],
        
      }),
    });

    // separate stage for sonarqube

    const testStage = pipeline.addStage(
      new PipelineStage(this, "PipelineStage", {
         stageName: "sonarqube-scan",
      }),
    );

    // separate stage for OWASP ZAP Test

    const zaptestStage = pipeline.addStage(
      new ZAP(this, 'ZAP', {
          stageName: "ZapTest",
      }),
    );


    // separate stage for manual approval

    const manualapprovalStage = pipeline.addStage(
      new Production(this, 'Production', {
          stageName: "ManualApproval",
          env: { account: accounts.pipeline, region: mainRegion },
      }),
    );

    manualapprovalStage.addPre(new ManualApprovalStep("approval"))
  }
}

// import * as cdk from "aws-cdk-lib";
// // import * as codecommit from "aws-cdk-lib/aws-codecommit";
// import { Stack, StackProps, aws_codecommit } from "aws-cdk-lib";
// import { Construct } from "constructs";
// import {
//   CodeBuildStep,
//   CodePipeline,
//   CodePipelineSource,
//   ManualApprovalStep,
//   ShellStep,
// } from "aws-cdk-lib/pipelines";
// import { PipelineStage } from "./SonarQube";
// import { Production } from "./Production";
// import { accounts, mainRegion } from "./constant/account";
// import { ZAP } from "./ZAP";

// export class NexaraCdkDeploymentStack extends cdk.Stack {
//     constructor(scope: Construct, id: string, props?: cdk.StackProps) {
//       super(scope, id, props);
  
//       const repo = aws_codecommit.Repository.fromRepositoryArn(
//         this,
//         id,
//         `arn:aws:codecommit:${Stack.of(this).region}:${Stack.of(this).account}:pocnexararepo`);

//       const prebuild = new cdk.pipelines.ShellStep('Prebuild', {
//        input: cdk.pipelines.CodePipelineSource.gitHub('myorg/repo1', 'main'),
//        primaryOutputDirectory: './build',
//        commands: ['./build.sh'],
//       });
  
//       const pipeline = new cdk.pipelines.CodePipeline(this, 'Pipeline', {
//        synth: new cdk.pipelines.ShellStep('Synth', {
//        input: cdk.pipelines.CodePipelineSource.codeCommit('myorg/repo2', 'main'),
//        additionalInputs: {
//         'subdir': cdk.pipelines.CodePipelineSource.gitHub('myorg/repo3', 'main'),
//         '../siblingdir': prebuild,
//       },
  
//        commands: ['./build.sh'],
//     })
//   });
// }
// }