export const accounts = {
    pipeline: '733639647768',
};
 
export const mainRegion = "us-east-1";